#include "dateClass.h"
#include <iostream>
using namespace std;

//default Constructor, assigns DEFAULT values
dateClass::dateClass(): month(1),day(1),year(1970) {
} // end default constructor

//Constructor for passed parameters
dateClass::dateClass(int initialMonth, int initialDay, int initialYear) {
    month = initialMonth;
    day = initialDay;
    year = initialYear;
}

// redefine month
void dateClass::setMonth(int newMonth) {
    month = newMonth;
}
// redefine day
void dateClass::setDay(int newDay) {
    day = newDay;
}
// redefine year
void dateClass::setYear(int newYear) {
    year = newYear;
}

// redefine all date values
void dateClass::setDate(int newMonth, int newDay, int newYear) {
    month = newMonth;
    day = newDay;
    year = newYear;
}

// get $year from private OBJECT value
int dateClass::getYear() const {
    return year;
}

// get $month from private OBJECT value
int dateClass::getMonth() const {
    return month;
}

// get $day from private OBJECT value
int dateClass::getDay() const {
    return day;
}

// Display all values in MM/DD/YYYY format
void dateClass::Display() {
    cout << getMonth()
         << '/' << getDay()
         << '/' << getYear();
}

// Deconstructor
dateClass::~dateClass() {
    //cout << "\nleaving scope / destroying object";
}