#include <cstdlib>
#include <iostream>
#include "dateClass.h"

using namespace std;


int main()
{
    
    dateClass firObj;               // 1st OBJECT, default values
    dateClass secObj(5,15,2015);    // 2nd OBJECT, custom values
    
    //firObj.Display();               // display 1st OBJ values
    
    firObj.setDate(3,17,2016);      // revise all 1st OBJ values
 
    firObj.Display();               // display new 1st OBJ values
    
    cout << endl;                   // new line for readability
    
    secObj.Display();               // display 2nd OBJ values

    return 0;   // Exit program cleanly
}