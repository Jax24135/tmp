#ifndef DATECLASS_H
#define DATECLASS_H

class dateClass {
    
    public:
        dateClass();
        // Default Constructor: Used to create default OBJECT
        // Post Condition: Sets new OBJECT members to
        // month = 1, day = 1, year = 1970.
    
        dateClass(int month,int day, int year);
        // Constructor: Create new OBJECT with given parameters
        // PostCondition: Uses given parameters to assign to (MM,DD,YYYY)
        // to new OBJECT
        
        void setMonth(int newMonth);
        // Alters the $month value
        // PostCondition: the OBJECT's $month is set to the passed parameter
        // newMonth: newMonth value to be assigned to $month
        
        void setDay(int newDay);
        // Alters the $day value
        // PostCondition: the OBJECT's $day is set to the passed parameter
        // newDay: newDay value to be assigned to $day
        
        void setYear(int newYear);
        // Alters the $year value
        // PostCondition: the OBJECT's $year is set to the passed parameter
        // newYear: newYear value to be assigned to $year
        
        void setDate(int newMonth, int newDay, int newYear);
        // Alters all members ($month,$day,$year) to new values
        // PostCondition: The $month is set from newMonth,
        // $day is set from newDay, && $year is set from newYear
        // newMonth: new MONTH value to be assigned to $month
        // newDay: new DAY value to be assigend to $day
        // newYear: new YEAR value to be assigned to $year
        
        
        int getMonth() const;
        // Shows the $month of OBJECT
        // PostCondition: Returns $month value
        
        int getDay() const;
        // Shows the $day of OBJECT
        // PostCondition: Returns $day value
        
        int getYear() const;
        // Shows the $year of OBJECT
        // PostCondition: Returns $year value
        
        void Display();
        // Shows the values of $month, $day, && $year of OBJECT
        // PostCondition: Returns $month, $day, $year shown as MM/DD/YYYY
        
        ~dateClass();
        // Destructor
        
    // hidden DATA
    private:
        int month;  //contains the month
        int day;    //contains the day
        int year;   // contains the year
};

#endif /* DATECLASS_H */    //end HEADER defintion