#ifndef FRACTION_H
#define FRACTION_H

#include <iostream>
#include <string>

using namespace std;

// Header file fraction.h declares class Fraction.

class Fraction
// Class Fraction represents the numerator and
// denominator of a fraction.

{
public:
  
  // Constructors

  Fraction();
  // Default Constructor
  // Post: Numerator and denominator have been set to zero

  Fraction(int n, int d);
  // Value Constructor
  // Post: Numerator and denominator are set to passed parameter values

  Fraction(const Fraction &rhs);
  // copy constructor
  // Post: Numerator has been set to the Numerator of the right-hand-side object
  //       denominator has been set to the Denominator of the right-hand-side object

  
  // mutators
  void Read();
  // Prompts User for (keyboard) input to set values for Numerator and Denominator
  // Post: Numerator has been set
  //       Denominator has been set
  
  void SetNumerator(int num);
  // Passes a new int value parameter to save as numerator
  // Post: New Numerator value is set
  
  void SetDenominator(int denom);
  // Passes a new int value parameter to save as denominator
  // Post: New Denominator value is set
  
  Fraction Add(const Fraction &rhs);
  // Finds Greatest Common Denominators and computes new values for numerators
  // so Fraction values can be added as existing ratio (ex: 1/2 + 4/10 as 5/10 + 4/10)
  // Post: self + rhs Fraction is returned.
  
  
  // accessors

  void Display() const;
  // Shows current self numerator and denominator values, no params required
  // Post: Displays self Fraction values as numerator/denominator
  
  void DisplayReducedFraction() const;
  // Shows User an alternative fraction when fraction is reduced by greatest common denominator
  // Post:: Shows a reduced fraction
  
  bool LessThan(const Fraction &rhs) const;
  // Compares Self Fraction to Right-Hand-Side Fraction for greater value
  // Post: whether the self fraction is less than the rhs fraction is returned

  // overloaded operators
  bool operator> (const Fraction &rhs) const;
  // Compares Self-Fraction to Right-Hand-Side Fraction for greater value
  // Computed by dividing both numbers (via float division (1.0*) added)
  // Post: Returns true if Self-Fraction is greater than RHS Fraction

  bool operator!= (const Fraction &rhs) const;
  // Compares Self-Fraction to Right-Hand-Side Fraction
  // Computed by dividing both numbers as float division (1.0*) added
  // Post: Returns true if Self-Fraction is less than RHS Fraction

  // define overloaded << operator, display the fraction in the format :  numerator/denominator
  friend ostream& operator<< (ostream &os, const Fraction &rhs);

  // define overloaded >> operator
  friend istream& operator>> (istream &is, Fraction rhs);

  ~Fraction(); //destructor
private:
  int numerator;
  int denominator;
};

#endif