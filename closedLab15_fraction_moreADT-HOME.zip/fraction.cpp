// Implementation file fraction.cpp implements the member 
// functions of class Fraction.

#include "fraction.h"
 
// Hmmm... header file says set both to 0? - ask about $this
// default constructor
Fraction::Fraction() {
    numerator = 0;
    denominator = 1;
}

// value constructor
Fraction::Fraction (int n, int d) {
    numerator = n;
    denominator = d;
}

// copy constructor
Fraction::Fraction(const Fraction &rhs) {
    numerator = rhs.numerator;
    denominator = rhs.denominator;
}

// mutators
void Fraction::Read() {
    cout << "Enter numerator value: ";
    cin >> numerator;
    cin.ignore(100,'\n');
    cout << "Enter denominator value: ";
    cin >> denominator;
    cin.ignore(100,'\n');
    cout << endl;
}

void Fraction::SetNumerator(int num) {
	numerator = num;
}

void Fraction::SetDenominator(int denom) {
	denominator = denom;
}

// Add member w/o Greatest Common Denominator Fraction Reduction
Fraction Fraction::Add(const Fraction &rhs) {
    if (denominator == rhs.denominator) {
        return Fraction (numerator + rhs.numerator, denominator);
    } else{
        
        int tmpNum, tmpDenom;
        tmpNum = (numerator*rhs.denominator) + (rhs.numerator*denominator);
        tmpDenom = denominator * rhs.denominator;
        
        return Fraction (tmpNum, tmpDenom);
    }
}

void Fraction::DisplayReducedFraction() const {
    int gcd;

    for (int i=numerator; i>1;i--) {
        if ((numerator % i == 0) && (denominator % i == 0)) {
            gcd = i;
            break;
        }
    }
    
    //cout << "gcd is " << gcd << endl;        
    cout << numerator/gcd << '/' << denominator/gcd << endl;
}




bool Fraction::LessThan(const Fraction &rhs) const { 
    if ((1.0*numerator)/denominator < (1.0*rhs.numerator)/rhs.denominator)
        return true;
    else
        return false;
}    

//accessors
void Fraction::Display() const {
    cout << numerator << '/' << denominator << endl;
}


// define the overloaded > operator
bool Fraction::operator> (const Fraction &rhs) const {
  if (((1.0*numerator)/denominator) > ((1.0*rhs.numerator)/rhs.denominator))
        return true;
    else
        return false;
}    

// define the overloaded != operator
bool Fraction::operator!= (const Fraction &rhs) const {
 if (((1.0*numerator)/denominator) != ((1.0*rhs.numerator)/rhs.denominator))
     return true;
 else
    return false;
}

ostream& operator<< (ostream &os, const Fraction &rhs) {
  os << rhs.numerator;
  os << '/';
  os << rhs.denominator;
  return os;
}

/*
 // define the overloaded >> operator
 // JonNOTE: getting compile error even though a 'friend' of OBJ method?
 istream& operator>> (istream &is, Fraction &rhs) {
   is >> rhs.numerator;
   is >> rhs.denominator;
   return is;
 }
 */

//destructor
Fraction::~Fraction() {    
}