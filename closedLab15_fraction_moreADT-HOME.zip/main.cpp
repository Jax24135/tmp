// asgn BY Jonathan Jackson,  CSCI 2170-001, Due: Midnight, Monday, 10/30/2017
// PROGRAM ID:  main.cpp / Fraction ADT Practice with members
// AUTHOR:  Jonathan Jackson
// INSTALLATION:  MTSU
// REMARKS: This program works with basic Class/Object members and data manipulation.
// Using a skeleton file, it displays new default fractions, set-by-value fractions,
// fractions with denominator-only changes and addition between differing fractions
// There's a bonus option @endOfFile to show a reduced version of the fraction.

#include "fraction.h"
#include <iostream>
using namespace std;
int main() {
    
// use the default constructor to declare an fraction object, frac1
    Fraction frac1;
    
// use the "Read" method to read from keyboard and assign numerator and denominator values for frac1,
// input 3 for the numerator value, and 10 for the denominator value
    frac1.Read();
    
    
// use the "Display" method to display frac1
    cout << "New frac1 fraction is ";
    frac1.Display();
    cout << endl;
    
// declare a second fraction object, frac2, using the copy constructor
// and let frac2 be initialized as a copy of frac1
    Fraction frac2(frac1);
    
// use the SetDenominator method to change the denominator of frac2 to 5
    frac2.SetDenominator(5);
    
// use the overloaded > operator to determine which fraction, frac1 or frac2, is bigger,
// display the info on which fraction is bigger
    if (frac1.LessThan(frac2))
        cout << "frac2 is larger than frac1\n\n";
    else
        cout << "frac1 is larger than frac2\n\n";
    
// use the default constructor to declare the third fraction object, frac3
    Fraction frac3;
     
// use the Add operator to add frac1 and frac2, and assign the resulting fraction to frac3
    frac3 = frac1.Add(frac2);
    
// use the "Display" method to display frac3
    cout << "New frac3 fraction is ";
    frac3.Display();
    //cout << "or a reduced fraction is ";
    //frac3.DisplayReducedFraction();
    // cout << endl;
    

    return 0;
}